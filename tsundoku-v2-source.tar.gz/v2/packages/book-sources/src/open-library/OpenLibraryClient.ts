import type { BookMetadata, BookSearchField, BookSearchLanguage, BookSearchResult, BookSource } from "../types";
import { getJson } from "../http";
import { mapOpenLibraryDoc, mapOpenLibraryWork, type OpenLibraryDoc, type OpenLibraryWork } from "./mapper";

const openLibraryLanguages: Record<Exclude<BookSearchLanguage, "all">, string> = {
  fr: "fre",
  en: "eng",
  de: "ger",
  es: "spa",
  it: "ita"
};

const openLibraryPrefix: Record<Exclude<BookSearchField, "author">, string> = {
  all: "",
  title: "title:",
  isbn: "isbn:"
};

interface OpenLibraryAuthorDoc {
  key?: string;
  name?: string;
}

interface OpenLibraryAuthorSearchResponse {
  docs?: OpenLibraryAuthorDoc[];
}

interface OpenLibraryAuthorWorksResponse {
  entries?: OpenLibraryWork[];
  size?: number;
}

interface OpenLibraryEditionDoc {
  key?: string;
  title?: string;
  publisher?: string[];
  isbn?: string[];
  isbn_10?: string[];
  isbn_13?: string[];
  number_of_pages?: number;
  language?: string[];
  cover_i?: number;
  publish_date?: string;
}

interface OpenLibraryEditionGroup {
  docs?: OpenLibraryEditionDoc[];
}

interface OpenLibraryWorkWithEditions extends OpenLibraryDoc {
  editions?: OpenLibraryEditionGroup;
}

function normalizeName(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function cleanIsbn(value: string): string {
  return value.replace(/[^0-9Xx]/g, "").toUpperCase();
}

function editionCover(id?: number): string | undefined {
  return id ? `https://covers.openlibrary.org/b/id/${id}-L.jpg` : undefined;
}

export class OpenLibraryClient implements BookSource {
  readonly id = "open-library" as const;

  constructor(private readonly base = "https://openlibrary.org") {}

  private async findAuthor(query: string): Promise<OpenLibraryAuthorDoc | null> {
    const p = new URLSearchParams({ q: query, limit: "10" });
    const data = await getJson<OpenLibraryAuthorSearchResponse>(`${this.base}/search/authors.json?${p}`);
    const authors = (data.docs ?? []).filter(author => author.key && author.name);
    if (!authors.length) return null;

    const wanted = normalizeName(query);
    return authors.find(author => normalizeName(author.name ?? "") === wanted) ?? authors[0] ?? null;
  }

  /**
   * Recherche d'auteur dans une langue précise.
   *
   * Open Library sait sélectionner, dans le champ `editions`, l'édition qui
   * correspond au filtre language:xxx. On utilise donc directement Search API
   * ici au lieu de récupérer les Works puis d'essayer de deviner leur langue.
   * Une œuvre n'est retournée que si Open Library connaît réellement au moins
   * une édition dans la langue demandée.
   */
  private async searchAuthorInLanguage(
    authorKey: string,
    authorName: string,
    language: Exclude<BookSearchLanguage, "all">,
    offset: number
  ): Promise<BookSearchResult[]> {
    const wanted = openLibraryLanguages[language];
    const q = `author_key:${authorKey} language:${wanted}`;
    const p = new URLSearchParams({
      q,
      lang: language,
      limit: "40",
      offset: String(Math.max(0, offset)),
      fields: [
        "key", "title", "author_name", "first_publish_year",
        "editions", "editions.key", "editions.title", "editions.publisher",
        "editions.isbn", "editions.isbn_10", "editions.isbn_13",
        "editions.number_of_pages", "editions.language", "editions.cover_i",
        "editions.publish_date"
      ].join(",")
    });

    const data = await getJson<{ docs?: OpenLibraryWorkWithEditions[] }>(`${this.base}/search.json?${p}`);

    return (data.docs ?? []).flatMap(doc => {
      // Avec language:xxx, l'édition renvoyée est celle sélectionnée par Open
      // Library pour cette langue. On ne retombe jamais sur le titre du Work :
      // cela évite d'afficher un titre allemand/anglais dans des résultats FR.
      const edition = doc.editions?.docs?.[0];
      if (!edition) return [];

      const editionLanguages = edition.language ?? [];
      if (editionLanguages.length > 0 && !editionLanguages.includes(wanted)) return [];

      const work = mapOpenLibraryDoc(doc);
      const isbns = [
        ...(edition.isbn ?? []),
        ...(edition.isbn_10 ?? []),
        ...(edition.isbn_13 ?? [])
      ].map(cleanIsbn);

      return [{
        ...work,
        sourceId: work.sourceId,
        title: edition.title?.trim() || work.title,
        authors: work.authors.length ? work.authors : [authorName],
        publisher: edition.publisher?.[0],
        isbn10: isbns.find(value => value.length === 10),
        isbn13: isbns.find(value => value.length === 13),
        pageCount: edition.number_of_pages,
        language: wanted,
        coverUrl: editionCover(edition.cover_i) ?? work.coverUrl
      }];
    });
  }

  private async searchAuthorWorks(query: string, language: BookSearchLanguage, offset: number): Promise<BookSearchResult[]> {
    const author = await this.findAuthor(query);
    if (!author?.key) return [];

    const key = author.key.replace(/^\/authors\//, "");

    // La langue est une préférence de classement dans Tsundoku, jamais un
    // filtre destructeur. Une recherche auteur conserve donc la bibliographie.
    const p = new URLSearchParams({ limit: "40", offset: String(Math.max(0, offset)) });
    const data = await getJson<OpenLibraryAuthorWorksResponse>(`${this.base}/authors/${encodeURIComponent(key)}/works.json?${p}`);
    return (data.entries ?? []).map(work => ({
      ...mapOpenLibraryWork(work, work.key ?? ""),
      authors: [author.name ?? query]
    }));
  }

  async search(
    query: string,
    language: BookSearchLanguage = "all",
    offset = 0,
    field: BookSearchField = "all"
  ): Promise<BookSearchResult[]> {
    query = query.trim();
    if (!query) return [];

    if (field === "author") return this.searchAuthorWorks(query, language, offset);

    const q = `${openLibraryPrefix[field]}${query}`.trim();
    const values: Record<string, string> = {
      q,
      limit: "40",
      offset: String(Math.max(0, offset)),
      fields: "key,title,author_name,first_publish_year,publisher,isbn,number_of_pages_median,language,cover_i,first_sentence"
    };
    const p = new URLSearchParams(values);
    const data = await getJson<{ docs?: OpenLibraryDoc[] }>(`${this.base}/search.json?${p}`);
    return (data.docs ?? []).map(mapOpenLibraryDoc);
  }

  async getBook(id: string): Promise<BookMetadata> {
    id = id.trim();
    if (!id) throw new Error("Open Library work id cannot be empty.");
    const key = id.startsWith("/") ? id : `/works/${id.replace(/^works\//, "")}`;
    return mapOpenLibraryWork(await getJson<OpenLibraryWork>(`${this.base}${key}.json`), key);
  }
}
