import { useEffect, useMemo, useState, type FormEvent } from "react";
import { Capacitor } from "@capacitor/core";
import { App as CapacitorApp } from "@capacitor/app";
import type { BookSearchResult } from "@tsundoku/book-sources";
import type { ReadingStatus } from "@tsundoku/database";
import { enrichSearchResults, getBookLanguageGroup, getBookLanguageLabel, mergeSearchResults, searchBooks, type BookSearchField, type BookSearchLanguage, type SearchProvider } from "./services/bookSearch";
import { getPreferredBookLanguage, setPreferredBookLanguage } from "./services/preferences";
import { deleteGoogleBooksApiKey, hasGoogleBooksApiKey, saveGoogleBooksApiKey } from "./services/credentials";
import {
  addBookToLibrary,
  initializeLibrary,
  removeBookFromLibrary,
  updateLibraryBook,
  getReadingSessions,
  addReadingSession,
  type LibraryBook,
  type ReadingSession
} from "./services/library";
import "./styles.css";

const statusLabels: Record<ReadingStatus, string> = {
  TO_READ: "À lire",
  READING: "En cours",
  READ: "Lu",
  ON_HOLD: "En pause",
  ABANDONED: "Abandonné"
};

type LibraryFilter = "ALL" | ReadingStatus | "FAVORITES";
type LibrarySort = "RECENT" | "TITLE" | "AUTHOR" | "PROGRESS";

function SearchCard({ b, onAdd, added }: {
  b: BookSearchResult; onAdd?: (b: BookSearchResult) => void; added?: boolean;
}) {
  return <article className="card">
    {b.coverUrl ? <img src={b.coverUrl} alt="" /> : <div className="cover">📖</div>}
    <div>
      <small>{b.source === "google-books" ? "Google Books" : b.source === "bnf" ? "BnF" : "Open Library"} · <span className="language-badge">{getBookLanguageLabel(b)}</span></small>
      <h3>{b.title}</h3>
      <p>{b.authors.join(", ") || "Auteur inconnu"}</p>
      {onAdd && <button disabled={added} onClick={() => onAdd(b)}>{added ? "Ajouté" : "Ajouter"}</button>}
    </div>
  </article>;
}

function LibraryCard({ b, onOpen }: { b: LibraryBook; onOpen: (b: LibraryBook) => void }) {
  const progress = b.progressTotal && b.progressValue != null
    ? Math.min(100, Math.round((b.progressValue / b.progressTotal) * 100))
    : undefined;

  return <article className="card library-card" onClick={() => onOpen(b)}>
    {b.coverUrl ? <img src={b.coverUrl} alt="" /> : <div className="cover">📖</div>}
    <div>
      <small>{statusLabels[b.status]} {b.favorite ? "★" : ""}</small>
      <h3>{b.title}</h3>
      <p>{b.authors.join(", ") || "Auteur inconnu"}</p>
      {progress != null && <div className="progress"><i style={{ width: `${progress}%` }} /></div>}
      {progress != null && <p>{progress}% · {b.progressValue}/{b.progressTotal}</p>}
    </div>
  </article>;
}

function countStatus(library: LibraryBook[], status: ReadingStatus) {
  return library.filter(book => book.status === status).length;
}

function progressPercent(book: LibraryBook) {
  if (!book.progressTotal || book.progressValue == null) return -1;
  return Math.min(100, (book.progressValue / book.progressTotal) * 100);
}

function localDateTimeValue(date = new Date()) {
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
}

function formatSessionDate(value: string) {
  return new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value));
}

export default function App() {
  const [view, setView] = useState<"home" | "library" | "add" | "detail" | "settings">("home");
  const [library, setLibrary] = useState<LibraryBook[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [dbState, setDbState] = useState<"loading" | "ready" | "error">("loading");
  const [dbError, setDbError] = useState("");
  const [q, setQ] = useState("");
  const [provider, setProvider] = useState<SearchProvider>("all");
  const [searchField, setSearchField] = useState<BookSearchField>("all");
  const [searchOffset, setSearchOffset] = useState(0);
  const [canLoadMore, setCanLoadMore] = useState(false);
  const [activeSearchLanguage, setActiveSearchLanguage] = useState<BookSearchLanguage>(() => getPreferredBookLanguage());
  const [preferredLanguage, setPreferredLanguageState] = useState<BookSearchLanguage>(() => getPreferredBookLanguage());
  const [lastSearchHadNoPreferredResults, setLastSearchHadNoPreferredResults] = useState(false);
  const [results, setResults] = useState<BookSearchResult[]>([]);
  const [showOtherLanguages, setShowOtherLanguages] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [libraryQuery, setLibraryQuery] = useState("");
  const [libraryFilter, setLibraryFilter] = useState<LibraryFilter>("ALL");
  const [librarySort, setLibrarySort] = useState<LibrarySort>("RECENT");
  const [googleKey, setGoogleKey] = useState("");
  const [googleKeyConfigured, setGoogleKeyConfigured] = useState(false);
  const [credentialBusy, setCredentialBusy] = useState(false);
  const [credentialMessage, setCredentialMessage] = useState("");
  const [deleteBusy, setDeleteBusy] = useState(false);
  const [sessions, setSessions] = useState<ReadingSession[]>([]);
  const [sessionDate, setSessionDate] = useState(() => localDateTimeValue());
  const [sessionDuration, setSessionDuration] = useState(30);
  const [sessionEndProgress, setSessionEndProgress] = useState("");
  const [sessionNotes, setSessionNotes] = useState("");
  const [sessionBusy, setSessionBusy] = useState(false);

  const selected = library.find(b => b.id === selectedId);
  const seriesBooks = useMemo(() => {
    if (!selected?.seriesName) return [];
    const wanted = selected.seriesName.trim().toLocaleLowerCase("fr");
    return library
      .filter(book => book.seriesName?.trim().toLocaleLowerCase("fr") === wanted)
      .sort((a, b) => (a.seriesVolume ?? Number.MAX_SAFE_INTEGER) - (b.seriesVolume ?? Number.MAX_SAFE_INTEGER));
  }, [library, selected?.seriesName]);
  const missingSeriesVolumes = useMemo(() => {
  const volumes = seriesBooks
    .map(book => book.seriesVolume)
    .filter((v): v is number => typeof v === "number" && Number.isInteger(v) && v > 0);
    if (volumes.length < 2) return [];
    const present = new Set(volumes);
    const max = Math.max(...volumes);
    const missing: number[] = [];
    for (let volume = 1; volume <= max; volume++) if (!present.has(volume)) missing.push(volume);
    return missing;
  }, [seriesBooks]);

  const filteredLibrary = useMemo(() => {
    const needle = libraryQuery.trim().toLocaleLowerCase("fr");
    const books = library.filter(book => {
      const matchesFilter =
        libraryFilter === "ALL" ||
        (libraryFilter === "FAVORITES" ? book.favorite : book.status === libraryFilter);

      if (!matchesFilter) return false;
      if (!needle) return true;

      const haystack = [
        book.title,
        ...book.authors,
        book.isbn10 ?? "",
        book.isbn13 ?? "",
        book.publisher ?? ""
      ].join(" ").toLocaleLowerCase("fr");

      return haystack.includes(needle);
    });

    return [...books].sort((a, b) => {
      if (librarySort === "TITLE") return a.title.localeCompare(b.title, "fr");
      if (librarySort === "AUTHOR") return (a.authors[0] ?? "").localeCompare(b.authors[0] ?? "", "fr");
      if (librarySort === "PROGRESS") return progressPercent(b) - progressPercent(a);
      return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
    });
  }, [library, libraryFilter, libraryQuery, librarySort]);

  useEffect(() => {
    let active = true;
    initializeLibrary().then(
      books => { if (active) { setLibrary(books); setDbState("ready"); } },
      err => {
        if (active) {
          console.error("Tsundoku SQLite initialization failed:", err);
          setDbError(err instanceof Error ? err.message : String(err));
          setDbState("error");
        }
      }
    );
    return () => { active = false; };
  }, []);

  useEffect(() => {
    void hasGoogleBooksApiKey().then(setGoogleKeyConfigured).catch(err => {
      console.error("Credential storage initialization failed:", err);
    });
  }, []);

  useEffect(() => {
    if (!selectedId) { setSessions([]); return; }
    let active = true;
    void getReadingSessions(selectedId).then(value => { if (active) setSessions(value); }).catch(err => {
      if (active) setError(err instanceof Error ? err.message : "Impossible de charger les sessions.");
    });
    return () => { active = false; };
  }, [selectedId]);

  useEffect(() => {
  if (!Capacitor.isNativePlatform()) return;

  const listener = CapacitorApp.addListener("backButton", () => {
    setView(current => {
      if (current === "detail") {
        setSelectedId(null);
        return "library";
      }

      if (current === "library" || current === "add" || current === "settings") {
        return "home";
      }

      void CapacitorApp.exitApp();
      return current;
    });
  });

  return () => {
    void listener.then(handle => handle.remove());
  };
}, []);

  const isAdded = (b: BookSearchResult) => library.some(x =>
    (b.isbn13 && x.isbn13 === b.isbn13) ||
    (b.isbn10 && x.isbn10 === b.isbn10) ||
    (x.source === b.source && x.sourceId === b.sourceId));

  function enrichInBackground(found: BookSearchResult[], language: BookSearchLanguage) {
    void enrichSearchResults(found, language).then(enriched => {
      setResults(current => mergeSearchResults([...current, ...enriched]));
    }).catch(() => {
      // L'enrichissement (jaquettes/métadonnées) ne doit jamais bloquer la recherche.
    });
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const found = await searchBooks(q, provider, preferredLanguage, 0, searchField);
      setResults(found);
      setShowOtherLanguages(false);
      setSearchOffset(40);
      setCanLoadMore(found.length > 0);
      setActiveSearchLanguage(preferredLanguage);
      setLastSearchHadNoPreferredResults(preferredLanguage !== "all" && found.length === 0);
      enrichInBackground(found, preferredLanguage);
    }
    catch (x) { setError(x instanceof Error ? x.message : "Recherche impossible"); }
    finally { setBusy(false); }
  }

  async function add(book: BookSearchResult) {
    setError("");
    try { setLibrary(await addBookToLibrary(book)); }
    catch (x) { setError(x instanceof Error ? x.message : "Impossible d'ajouter le livre."); }
  }

  async function patch(changes: Parameters<typeof updateLibraryBook>[1]) {
    if (!selected) return;
    try { setLibrary(await updateLibraryBook(selected.id, changes)); }
    catch (x) { setError(x instanceof Error ? x.message : "Modification impossible."); }
  }

  async function saveReadingSession(e: FormEvent) {
    e.preventDefault();
    if (!selected || sessionBusy) return;
    setSessionBusy(true);
    setError("");
    try {
      const endProgress = sessionEndProgress.trim() === "" ? undefined : Number(sessionEndProgress);
      const result = await addReadingSession(selected.id, {
        startedAt: new Date(sessionDate).toISOString(),
        durationMinutes: sessionDuration,
        endProgress,
        notes: sessionNotes
      });
      setLibrary(result.library);
      setSessions(result.sessions);
      setSessionDate(localDateTimeValue());
      setSessionEndProgress("");
      setSessionNotes("");
    } catch (x) {
      setError(x instanceof Error ? x.message : "Impossible d'enregistrer la session.");
    } finally {
      setSessionBusy(false);
    }
  }

  async function removeSelectedBook() {
    if (!selected || deleteBusy) return;
    const confirmed = window.confirm(
      `Supprimer « ${selected.title} » de votre bibliothèque ?\n\nCette action retirera également son état de lecture et sa progression.`
    );
    if (!confirmed) return;

    setDeleteBusy(true);
    setError("");
    try {
      setLibrary(await removeBookFromLibrary(selected.id));
      setSelectedId(null);
      setView("library");
    } catch (x) {
      setError(x instanceof Error ? x.message : "Suppression impossible.");
    } finally {
      setDeleteBusy(false);
    }
  }

  async function saveGoogleKey(e: FormEvent) {
    e.preventDefault();
    setCredentialBusy(true);
    setCredentialMessage("");
    try {
      await saveGoogleBooksApiKey(googleKey);
      setGoogleKey("");
      setGoogleKeyConfigured(true);
      setCredentialMessage("Clé Google Books enregistrée.");
    } catch (x) {
      setCredentialMessage(x instanceof Error ? x.message : "Impossible d'enregistrer la clé.");
    } finally {
      setCredentialBusy(false);
    }
  }

  async function removeGoogleKey() {
    setCredentialBusy(true);
    setCredentialMessage("");
    try {
      await deleteGoogleBooksApiKey();
      setGoogleKey("");
      setGoogleKeyConfigured(false);
      setCredentialMessage("Clé Google Books supprimée.");
    } catch (x) {
      setCredentialMessage(x instanceof Error ? x.message : "Impossible de supprimer la clé.");
    } finally {
      setCredentialBusy(false);
    }
  }

  async function searchAllLanguages() {
    setBusy(true);
    setError("");
    try {
      const found = await searchBooks(q, provider, "all", 0, searchField);
      setResults(found);
      setShowOtherLanguages(true);
      setSearchOffset(40);
      setCanLoadMore(found.length > 0);
      setActiveSearchLanguage("all");
      setLastSearchHadNoPreferredResults(false);
      enrichInBackground(found, "all");
    } catch (x) {
      setError(x instanceof Error ? x.message : "Recherche impossible");
    } finally {
      setBusy(false);
    }
  }

  async function loadMoreResults() {
    if (busy || !canLoadMore) return;
    setBusy(true);
    setError("");
    try {
      const found = await searchBooks(q, provider, activeSearchLanguage, searchOffset, searchField);
      setResults(current => mergeSearchResults([...current, ...found]));
      setSearchOffset(current => current + 40);
      setCanLoadMore(found.length > 0);
      enrichInBackground(found, activeSearchLanguage);
    } catch (x) {
      setError(x instanceof Error ? x.message : "Recherche impossible");
    } finally {
      setBusy(false);
    }
  }

  function changePreferredLanguage(language: BookSearchLanguage) {
    setPreferredLanguageState(language);
    setPreferredBookLanguage(language);
    setCredentialMessage("Langue préférée enregistrée.");
  }

  function openBook(b: LibraryBook) {
    setSelectedId(b.id);
    setView("detail");
  }

  const filterButtons: Array<[LibraryFilter, string, number]> = [
    ["ALL", "Tous", library.length],
    ["TO_READ", "À lire", countStatus(library, "TO_READ")],
    ["READING", "En cours", countStatus(library, "READING")],
    ["READ", "Lus", countStatus(library, "READ")],
    ["ON_HOLD", "En pause", countStatus(library, "ON_HOLD")],
    ["ABANDONED", "Abandonnés", countStatus(library, "ABANDONED")],
    ["FAVORITES", "★ Favoris", library.filter(book => book.favorite).length]
  ];

  return <div className="shell">
    <aside>
      <div className="brand">T <b>Tsundoku</b></div>
      <nav>
        <button onClick={() => setView("home")}>Accueil</button>
        <button onClick={() => setView("library")}>Bibliothèque</button>
        <button onClick={() => setView("add")}>Ajouter</button>
        <button onClick={() => setView("settings")}>Paramètres</button>
      </nav>
      <span>{dbState === "loading" && "◌ Initialisation SQLite…"}{dbState === "ready" && "● SQLite local"}{dbState === "error" && "⚠ SQLite indisponible"}</span>
    </aside>

    <main>
      <header>Tsundoku V2<h1>{view === "home" ? "Bonjour 👋" : view === "library" ? "Ma bibliothèque" : view === "add" ? "Ajouter un livre" : view === "settings" ? "Paramètres" : selected?.title ?? "Livre"}</h1></header>

      {dbState === "error" && <section className="hero"><h2>SQLite n'a pas pu démarrer</h2><p className="error">{dbError}</p></section>}

      {view === "home" && <>
        <section className="hero">
          <h2>Ta bibliothèque, disponible partout.</h2>
          <p>Parce que chaque livre mérite d'être lu.</p>
          <button disabled={dbState !== "ready"} onClick={() => setView("add")}>Ajouter un livre</button>
        </section>
        <section className="stats">
          <button onClick={() => { setLibraryFilter("ALL"); setView("library"); }}><strong>{library.length}</strong><span>Livres</span></button>
          <button onClick={() => { setLibraryFilter("READING"); setView("library"); }}><strong>{countStatus(library, "READING")}</strong><span>En cours</span></button>
          <button onClick={() => { setLibraryFilter("TO_READ"); setView("library"); }}><strong>{countStatus(library, "TO_READ")}</strong><span>À lire</span></button>
          <button onClick={() => { setLibraryFilter("READ"); setView("library"); }}><strong>{countStatus(library, "READ")}</strong><span>Lus</span></button>
        </section>
      </>}

      {view === "library" && <>
        <section className="library-toolbar">
          <div className="library-search">
            <input value={libraryQuery} onChange={e => setLibraryQuery(e.target.value)} placeholder="Rechercher dans ma bibliothèque…" />
            <select value={librarySort} onChange={e => setLibrarySort(e.target.value as LibrarySort)}>
              <option value="RECENT">Modifiés récemment</option>
              <option value="TITLE">Titre</option>
              <option value="AUTHOR">Auteur</option>
              <option value="PROGRESS">Progression</option>
            </select>
          </div>
          <div className="filter-row">
            {filterButtons.map(([value, label, count]) =>
              <button key={value} className={libraryFilter === value ? "filter active" : "filter"} onClick={() => setLibraryFilter(value)}>
                {label} <span>{count}</span>
              </button>
            )}
          </div>
        </section>

        <div className="library-summary">
          <h2>{filteredLibrary.length} livre{filteredLibrary.length > 1 ? "s" : ""}</h2>
          {(libraryQuery || libraryFilter !== "ALL") && <button className="text-button" onClick={() => { setLibraryQuery(""); setLibraryFilter("ALL"); }}>Effacer les filtres</button>}
        </div>

        {filteredLibrary.length > 0
          ? <div className="grid">{filteredLibrary.map(b => <LibraryCard key={b.id} b={b} onOpen={openBook} />)}</div>
          : <section className="empty-state"><div>📚</div><h2>Aucun livre trouvé</h2><p>Essaie un autre filtre ou une autre recherche.</p><button onClick={() => { setLibraryQuery(""); setLibraryFilter("ALL"); }}>Voir toute la bibliothèque</button></section>}
      </>}

      {view === "add" && <>
        <form className="search-form" onSubmit={submit}>
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Titre, auteur ou ISBN…" />
          <select value={searchField} onChange={e => setSearchField(e.target.value as BookSearchField)}>
            <option value="all">Recherche générale</option><option value="author">Auteur</option><option value="title">Titre</option><option value="isbn">ISBN</option>
          </select>
          <select value={provider} onChange={e => setProvider(e.target.value as SearchProvider)}>
            <option value="all">Toutes les sources</option><option value="bnf">BnF</option><option value="open-library">Open Library</option><option value="google-books">Google Books</option>
          </select>
          <button disabled={busy}>{busy ? "Recherche…" : "Rechercher"}</button>
        </form>
        {error && <p className="error">{error}</p>}
        {lastSearchHadNoPreferredResults && <section className="search-fallback"><p>Aucun résultat dans la langue préférée.</p><button type="button" onClick={() => void searchAllLanguages()}>Afficher toutes les langues</button></section>}
        {(() => {
          const visible = activeSearchLanguage === "all" || showOtherLanguages
            ? results
            : results.filter(book => getBookLanguageGroup(book, activeSearchLanguage) === "preferred");
          const hiddenCount = results.length - visible.length;
          return <>
            <div className="grid">{visible.map(b => <SearchCard key={`${b.source}-${b.sourceId}`} b={b} added={isAdded(b)} onAdd={dbState === "ready" ? add : undefined} />)}</div>
            {hiddenCount > 0 && <div className="load-more"><button type="button" onClick={() => setShowOtherLanguages(true)}>Afficher les autres langues / indéterminées ({hiddenCount})</button></div>}
          </>;
        })()}
        {results.length > 0 && canLoadMore && <div className="load-more"><button type="button" disabled={busy} onClick={() => void loadMoreResults()}>{busy ? "Chargement…" : "Charger plus"}</button></div>}
      </>}

      {view === "settings" && <section className="settings-card">
        <div className="settings-section">
          <p className="eyebrow">Recherche de livres</p>
          <h2>Langue préférée</h2>
          <p className="settings-help">La langue sert à classer les résultats, pas à les supprimer. En français, Tsundoku combine la BnF, Open Library et Google Books.</p>
          <label className="language-setting">Langue des résultats
            <select value={preferredLanguage} onChange={e => changePreferredLanguage(e.target.value as BookSearchLanguage)}>
              <option value="fr">Français</option>
              <option value="en">Anglais</option>
              <option value="de">Allemand</option>
              <option value="es">Espagnol</option>
              <option value="it">Italien</option>
              <option value="all">Toutes les langues</option>
            </select>
          </label>
        </div>
        <div className="settings-section settings-divider">
        <div className="settings-heading">
          <div>
            <p className="eyebrow">Sources de livres</p>
            <h2>Google Books</h2>
          </div>
          <span className={googleKeyConfigured ? "credential-status configured" : "credential-status"}>
            {googleKeyConfigured ? "● Clé configurée" : "○ Aucune clé"}
          </span>
        </div>
        <p className="settings-help">
          La clé est propre à cet appareil. Elle n'est enregistrée ni dans SQLite, ni dans les données synchronisables.
          Sur Android, elle est conservée dans le stockage sécurisé du système.
        </p>
        <form className="credential-form" onSubmit={saveGoogleKey}>
          <label>
            {googleKeyConfigured ? "Remplacer la clé API" : "Clé API Google Books"}
            <input
              type="password"
              autoComplete="off"
              value={googleKey}
              onChange={e => setGoogleKey(e.target.value)}
              placeholder={googleKeyConfigured ? "Saisir une nouvelle clé…" : "Saisir la clé…"}
            />
          </label>
          <div className="credential-actions">
            <button disabled={credentialBusy || !googleKey.trim()}>
              {credentialBusy ? "Enregistrement…" : googleKeyConfigured ? "Remplacer" : "Enregistrer"}
            </button>
            {googleKeyConfigured && <button type="button" className="danger-button" disabled={credentialBusy} onClick={() => void removeGoogleKey()}>Supprimer la clé</button>}
          </div>
        </form>
        {credentialMessage && <p className="credential-message">{credentialMessage}</p>}
        </div>
      </section>}

      {view === "detail" && selected && <section className="book-detail">
        <button className="secondary" onClick={() => setView("library")}>← Bibliothèque</button>
        <div className="detail-layout">
          <div>{selected.coverUrl ? <img className="detail-cover" src={selected.coverUrl} alt="" /> : <div className="detail-cover cover">📖</div>}</div>
          <div>
            <p className="eyebrow">{selected.authors.join(", ") || "Auteur inconnu"}</p><h2>{selected.title}</h2>
            <p>{selected.description || "Aucune description disponible."}</p>
            <div className="detail-grid">
              <label>Statut<select value={selected.status} onChange={e => patch({ status: e.target.value as ReadingStatus })}>
                {Object.entries(statusLabels).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select></label>
              <label className="check"><input type="checkbox" checked={selected.favorite} onChange={e => patch({ favorite: e.target.checked })} /> Favori ★</label>
              <label className="check"><input type="checkbox" checked={selected.owned} onChange={e => patch({ owned: e.target.checked })} /> Je possède ce livre</label>
              <label>Progression<input type="number" min="0" value={selected.progressValue ?? ""} onChange={e => patch({ progressValue: e.target.value === "" ? 0 : Number(e.target.value) })} /></label>
              <label>Total<input type="number" min="0" value={selected.progressTotal ?? ""} onChange={e => patch({ progressTotal: e.target.value === "" ? 0 : Number(e.target.value) })} /></label>
              <label>Série<input key={`${selected.id}-series-${selected.seriesName ?? ""}`} type="text" placeholder="Ex. La Belgariade" defaultValue={selected.seriesName ?? ""} onBlur={e => void patch({ seriesName: e.target.value })} /></label>
              <label>Tome<input key={`${selected.id}-volume-${selected.seriesVolume ?? ""}`} type="number" min="0" step="0.5" placeholder="Ex. 3" defaultValue={selected.seriesVolume ?? ""} onBlur={e => void patch({ seriesVolume: e.target.value === "" ? undefined : Number(e.target.value) })} /></label>
            </div>
            <p className="meta">{selected.publisher || "Éditeur inconnu"} {selected.publishedYear ? `· ${selected.publishedYear}` : ""} {selected.isbn13 ? `· ISBN ${selected.isbn13}` : ""}</p>
            {selected.seriesName && <section className="series-panel">
              <div className="session-heading">
                <div><p className="eyebrow">Série</p><h3>{selected.seriesName}</h3></div>
                <strong>{seriesBooks.filter(book => book.owned).length}/{seriesBooks.length} possédés</strong>
              </div>
              {missingSeriesVolumes.length > 0 && <p className="series-missing">Tomes manquants dans ta bibliothèque : {missingSeriesVolumes.join(", ")}</p>}
              <div className="series-list">
                {seriesBooks.map(book => <button type="button" key={book.id} className={book.id === selected.id ? "current" : ""} onClick={() => setSelectedId(book.id)}>
                  <span>{book.seriesVolume != null ? `Tome ${book.seriesVolume}` : "Tome ?"}</span>
                  <strong>{book.title}</strong>
                  <small>{book.owned ? "✓ Possédé" : "○ Non possédé"} · {statusLabels[book.status]}</small>
                </button>)}
              </div>
              <p className="meta">Renseigne la même série et le numéro de tome sur tes livres : Tsundoku détecte automatiquement les trous dans la suite.</p>
            </section>}
            <section className="reading-sessions">
              <div className="session-heading">
                <div><p className="eyebrow">Journal de lecture</p><h3>Sessions de lecture</h3></div>
                <strong>{sessions.reduce((sum, session) => sum + session.durationMinutes, 0)} min</strong>
              </div>
              <form className="session-form" onSubmit={saveReadingSession}>
                <label>Date et heure<input type="datetime-local" required value={sessionDate} onChange={e => setSessionDate(e.target.value)} /></label>
                <label>Durée (min)<input type="number" min="1" required value={sessionDuration} onChange={e => setSessionDuration(Number(e.target.value))} /></label>
                <label>Page / progression après la session<input type="number" min="0" max={selected.progressTotal} placeholder={selected.progressValue != null ? String(selected.progressValue) : "Optionnel"} value={sessionEndProgress} onChange={e => setSessionEndProgress(e.target.value)} /></label>
                <label className="session-notes">Notes<input type="text" placeholder="Optionnel" value={sessionNotes} onChange={e => setSessionNotes(e.target.value)} /></label>
                <button disabled={sessionBusy}>{sessionBusy ? "Enregistrement…" : "Enregistrer la session"}</button>
              </form>
              {sessions.length > 0 ? <div className="session-list">
                {sessions.map(session => <article key={session.id}>
                  <div><strong>{formatSessionDate(session.startedAt)}</strong><small>{session.durationMinutes} min{session.endProgress != null ? ` · progression ${session.endProgress}${selected.progressTotal ? `/${selected.progressTotal}` : ""}` : ""}</small></div>
                  {session.notes && <p>{session.notes}</p>}
                </article>)}
              </div> : <p className="meta">Aucune session enregistrée pour ce livre.</p>}
            </section>
            <div className="danger-zone">
              <div>
                <strong>Supprimer de ma bibliothèque</strong>
                <p>Retire ce livre, son statut et sa progression de ta bibliothèque.</p>
              </div>
              <button type="button" className="danger-button" disabled={deleteBusy} onClick={() => void removeSelectedBook()}>
                {deleteBusy ? "Suppression…" : "Supprimer"}
              </button>
            </div>
          </div>
        </div>
      </section>}
    </main>
  </div>;
}
