import { BnfClient, GoogleBooksClient, OpenLibraryClient, type BookSearchField, type BookSearchLanguage, type BookSearchResult } from "@tsundoku/book-sources";
import { getCredentialStore } from "./credentials";

export type SearchProvider = "all" | "bnf" | "open-library" | "google-books";
export type { BookSearchField, BookSearchLanguage };

const bnf = new BnfClient();
const openLibrary = new OpenLibraryClient();
const googleBooks = new GoogleBooksClient(getCredentialStore());

function normalize(value: string): string {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

function cleanIsbn(value?: string): string | undefined {
  const isbn = value?.replace(/[^0-9Xx]/g, "").toUpperCase();
  return isbn && (isbn.length === 10 || isbn.length === 13) ? isbn : undefined;
}

function isbn10To13(value: string): string | undefined {
  const isbn10 = cleanIsbn(value);
  if (!isbn10 || isbn10.length !== 10 || !/^\d{9}[\dX]$/.test(isbn10)) return undefined;
  const base = `978${isbn10.slice(0, 9)}`;
  const sum = [...base].reduce((total, digit, index) => total + Number(digit) * (index % 2 === 0 ? 1 : 3), 0);
  return `${base}${(10 - (sum % 10)) % 10}`;
}

function canonicalIsbn(book: BookSearchResult): string | undefined {
  const isbn13 = cleanIsbn(book.isbn13);
  if (isbn13?.length === 13) return isbn13;
  const isbn10 = cleanIsbn(book.isbn10);
  return isbn10?.length === 10 ? isbn10To13(isbn10) : undefined;
}

function mergeBook(previous: BookSearchResult, next: BookSearchResult): BookSearchResult {
  // La notice qui possède déjà une jaquette est préférée comme base visuelle,
  // puis les métadonnées manquantes sont complétées par l'autre source.
  const base = previous.coverUrl ? previous : next.coverUrl ? next : previous;
  const other = base === previous ? next : previous;
  return {
    ...base,
    authors: base.authors.length ? base.authors : other.authors,
    publishedYear: base.publishedYear ?? other.publishedYear,
    publisher: base.publisher ?? other.publisher,
    isbn10: base.isbn10 ?? other.isbn10,
    isbn13: base.isbn13 ?? other.isbn13,
    pageCount: base.pageCount ?? other.pageCount,
    language: base.language ?? other.language,
    description: base.description ?? other.description,
    coverUrl: base.coverUrl ?? other.coverUrl
  };
}

export function mergeSearchResults(books: BookSearchResult[]): BookSearchResult[] {
  const unique = new Map<string, BookSearchResult>();
  for (const book of books) {
    const isbn = canonicalIsbn(book);
    const fallback = `${normalize(book.title)}::${normalize(book.authors[0] ?? "")}`;
    const key = isbn ? `isbn:${isbn}` : `text:${fallback}`;
    const previous = unique.get(key);
    unique.set(key, previous ? mergeBook(previous, book) : book);
  }
  return [...unique.values()];
}

const languageAliases: Record<Exclude<BookSearchLanguage, "all">, string[]> = {
  fr: ["fr", "fre", "fra", "francais", "french"],
  en: ["en", "eng", "anglais", "english"],
  de: ["de", "ger", "deu", "allemand", "german"],
  es: ["es", "spa", "espagnol", "spanish"],
  it: ["it", "ita", "italien", "italian"]
};

function normalizedLanguage(value?: string): string {
  return normalize(value ?? "");
}

export type BookLanguageGroup = "preferred" | "unknown" | "other";

export function getBookLanguageGroup(book: BookSearchResult, language: BookSearchLanguage): BookLanguageGroup {
  if (language === "all") return "preferred";
  const value = normalizedLanguage(book.language);
  if (!value) return "unknown";
  if (languageAliases[language].some(alias => value === alias || value.startsWith(`${alias} `) || value.startsWith(`${alias}-`))) return "preferred";
  return "other";
}

export function getBookLanguageLabel(book: BookSearchResult): string {
  const value = normalizedLanguage(book.language);
  if (!value) return "?";
  for (const [code, aliases] of Object.entries(languageAliases)) {
    if (aliases.some(alias => value === alias || value.startsWith(`${alias} `) || value.startsWith(`${alias}-`))) {
      return code.toUpperCase();
    }
  }
  return book.language?.trim().slice(0, 5).toUpperCase() || "?";
}

function sameBook(a: BookSearchResult, b: BookSearchResult): boolean {
  const aIsbn = canonicalIsbn(a);
  const bIsbn = canonicalIsbn(b);
  if (aIsbn && bIsbn) return aIsbn === bIsbn;

  const titleA = normalize(a.title);
  const titleB = normalize(b.title);
  if (!titleA || titleA !== titleB) return false;
  const authorA = normalize(a.authors[0] ?? "");
  const authorB = normalize(b.authors[0] ?? "");
  return !authorA || !authorB || authorA === authorB || authorA.includes(authorB) || authorB.includes(authorA);
}

async function findMetadataForBnf(book: BookSearchResult): Promise<BookSearchResult | undefined> {
  const isbn = canonicalIsbn(book) ?? cleanIsbn(book.isbn10);
  if (isbn) {
    const settled = await Promise.allSettled([
      googleBooks.search(isbn, "all", 0, "isbn"),
      openLibrary.search(isbn, "all", 0, "isbn")
    ]);
    const exact = settled.flatMap(result => result.status === "fulfilled" ? result.value : [])
      .find(candidate => canonicalIsbn(candidate) === canonicalIsbn(book));
    if (exact) return exact;
  }

  const query = [book.title, book.authors[0]].filter(Boolean).join(" ");
  if (!query) return undefined;
  const settled = await Promise.allSettled([
    googleBooks.search(query, "all", 0, "all"),
    openLibrary.search(book.title, "all", 0, "title")
  ]);
  return settled.flatMap(result => result.status === "fulfilled" ? result.value : [])
    .find(candidate => sameBook(book, candidate));
}

async function mapWithConcurrency<T, R>(items: T[], concurrency: number, work: (item: T) => Promise<R>): Promise<R[]> {
  const results = new Array<R>(items.length);
  let next = 0;
  async function worker() {
    while (true) {
      const index = next++;
      if (index >= items.length) return;
      results[index] = await work(items[index]);
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, () => worker()));
  return results;
}

const bnfEnrichmentCache = new Map<string, Promise<BookSearchResult>>();

function enrichmentKey(book: BookSearchResult): string {
  return canonicalIsbn(book) ?? `${normalize(book.title)}::${normalize(book.authors[0] ?? "")}`;
}

async function enrichBnfBook(book: BookSearchResult): Promise<BookSearchResult> {
  if (book.source !== "bnf" || (book.coverUrl && book.language)) return book;
  const key = enrichmentKey(book);
  const cached = bnfEnrichmentCache.get(key);
  if (cached) return cached;
  const promise = (async () => {
    try {
      const metadata = await findMetadataForBnf(book);
      if (!metadata) return book;
      return {
        ...book,
        language: book.language ?? metadata.language,
        pageCount: book.pageCount ?? metadata.pageCount,
        description: book.description ?? metadata.description,
        coverUrl: book.coverUrl ?? metadata.coverUrl
      };
    } catch {
      return book;
    }
  })();
  bnfEnrichmentCache.set(key, promise);
  return promise;
}

export async function enrichSearchResults(books: BookSearchResult[], language: BookSearchLanguage): Promise<BookSearchResult[]> {
  const enriched = await mapWithConcurrency(books, 4, enrichBnfBook);
  return rank(mergeSearchResults(enriched), language);
}

function rank(books: BookSearchResult[], language: BookSearchLanguage): BookSearchResult[] {
  const weight: Record<BookLanguageGroup, number> = { preferred: 2, unknown: 1, other: 0 };
  return books.map((book, index) => ({ book, index, score: weight[getBookLanguageGroup(book, language)] }))
    .sort((a, b) => b.score - a.score || a.index - b.index)
    .map(item => item.book);
}

export async function searchBooks(q: string, p: SearchProvider, language: BookSearchLanguage = "all", offset = 0, field: BookSearchField = "all"): Promise<BookSearchResult[]> {
  q = q.trim();
  if (!q) return [];
  if (p === "bnf") return rank(mergeSearchResults(await bnf.search(q, language, offset, field)), language);
  if (p === "open-library") return rank(mergeSearchResults(await openLibrary.search(q, language, offset, field)), language);
  if (p === "google-books") return rank(mergeSearchResults(await googleBooks.search(q, language, offset, field)), language);

  // La BnF est interrogée pour le français (et le mode toutes langues). Pour
  // les autres langues, Open Library + Google Books restent les sources utiles.
  const searches = [openLibrary.search(q, language, offset, field), googleBooks.search(q, language, offset, field)];
  if (language === "fr" || language === "all") searches.unshift(bnf.search(q, language, offset, field));
  const settled = await Promise.allSettled(searches);
  const books = settled.flatMap(result => result.status === "fulfilled" ? result.value : []);
  if (!books.length && settled.every(result => result.status === "rejected")) throw new Error("Aucune source de livres n'est disponible.");
  const merged = mergeSearchResults(books);
  return rank(merged, language);
}
